import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

void main() {
  runApp(const TaskReminderApp());
}

class TaskReminderApp extends StatelessWidget {
  const TaskReminderApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: '任务提醒',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff0f766e)),
        scaffoldBackgroundColor: const Color(0xfff6fbf9),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          backgroundColor: Color(0xfff6fbf9),
          surfaceTintColor: Colors.transparent,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Color(0xffd7e5e0)),
          ),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
        outlinedButtonTheme: OutlinedButtonThemeData(
          style: OutlinedButton.styleFrom(
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
          ),
        ),
        chipTheme: const ChipThemeData(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(8)),
          ),
        ),
      ),
      home: const TaskHomePage(),
    );
  }
}

class ApiClient {
  ApiClient(this.baseUrl);

  String baseUrl;

  Uri _uri(String path) => Uri.parse('$baseUrl$path');

  Future<List<TaskItem>> listTasks({DateTime? date}) async {
    final path = date == null
        ? '/api/tasks'
        : '/api/tasks?date=${DateFormat('yyyy-MM-dd').format(date)}';
    final response = await http.get(_uri(path));
    final body = _decode(response);
    return ((body['data'] ?? []) as List)
        .map((item) => TaskItem.fromJson(item as Map<String, dynamic>))
        .toList();
  }

  Future<TaskItem> createTask({
    required String title,
    required DateTime remindTime,
    int intervalMinutes = 10,
    String? content,
    String category = '默认',
  }) async {
    final response = await http.post(
      _uri('/api/tasks'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'title': title,
        'content': content,
        'category': category,
        'remind_time': remindTime.toIso8601String(),
        'remind_interval_minutes': intervalMinutes,
      }),
    );
    return TaskItem.fromJson(_decode(response)['data'] as Map<String, dynamic>);
  }

  Future<TaskItem> parseCreate(String text) async {
    final response = await http.post(
      _uri('/api/tasks/parse-create'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'text': text}),
    );
    return TaskItem.fromJson(_decode(response)['data'] as Map<String, dynamic>);
  }

  Future<TaskDetail> getTask(int id) async {
    final response = await http.get(_uri('/api/tasks/$id'));
    return TaskDetail.fromJson(
        _decode(response)['data'] as Map<String, dynamic>);
  }

  Future<TaskItem> updateTask({
    required int id,
    required String title,
    required DateTime remindTime,
    required int intervalMinutes,
    required String category,
    String? content,
  }) async {
    final response = await http.put(
      _uri('/api/tasks/$id'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'title': title,
        'content': content,
        'category': category,
        'remind_time': remindTime.toIso8601String(),
        'remind_interval_minutes': intervalMinutes,
      }),
    );
    return TaskItem.fromJson(_decode(response)['data'] as Map<String, dynamic>);
  }

  Future<TaskItem> done(int id) => _taskAction('/api/tasks/$id/done');

  Future<TaskItem> cancel(int id) => _taskAction('/api/tasks/$id/cancel');

  Future<TaskItem> postpone(int id, int minutes) async {
    final response = await http.post(
      _uri('/api/tasks/$id/postpone'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'minutes': minutes}),
    );
    return TaskItem.fromJson(_decode(response)['data'] as Map<String, dynamic>);
  }

  Future<AppSettings> getSettings() async {
    final response = await http.get(_uri('/api/settings'));
    return AppSettings.fromJson(
        _decode(response)['data'] as Map<String, dynamic>);
  }

  Future<void> healthCheck() async {
    final response = await http.get(_uri('/health'));
    _decode(response);
  }

  Future<AppSettings> saveSettings(AppSettings settings) async {
    final response = await http.post(
      _uri('/api/settings'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode(settings.toJson()),
    );
    return AppSettings.fromJson(
        _decode(response)['data'] as Map<String, dynamic>);
  }

  Future<void> testDingding({
    required String webhook,
    String? secret,
  }) async {
    final response = await http.post(
      _uri('/api/settings/test-dingding'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'dingding_webhook': webhook,
        'dingding_secret': secret,
      }),
    );
    _decode(response);
  }

  Future<NotionImportResult> importNotionTasks({
    required String notionToken,
    required String dataSourceId,
    required String titleProperty,
    required String remindTimeProperty,
    required String contentProperty,
    required String categoryProperty,
    required String intervalProperty,
    required String statusProperty,
    required String createdTimeProperty,
    required int defaultIntervalMinutes,
  }) async {
    final response = await http.post(
      _uri('/api/tasks/notion/import'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({
        'notion_token': notionToken,
        'data_source_id': dataSourceId,
        'title_property': titleProperty,
        'remind_time_property': remindTimeProperty,
        'content_property': contentProperty,
        'category_property': categoryProperty,
        'interval_property': intervalProperty,
        'status_property': statusProperty,
        'created_time_property': createdTimeProperty,
        'default_interval_minutes': defaultIntervalMinutes,
      }),
    );
    return NotionImportResult.fromJson(
        _decode(response)['data'] as Map<String, dynamic>);
  }

  Future<TaskItem> _taskAction(String path) async {
    final response = await http.post(_uri(path));
    return TaskItem.fromJson(_decode(response)['data'] as Map<String, dynamic>);
  }

  Map<String, dynamic> _decode(http.Response response) {
    final body =
        jsonDecode(utf8.decode(response.bodyBytes)) as Map<String, dynamic>;
    if (response.statusCode >= 400 || body['code'] != 200) {
      throw ApiException('${body['message'] ?? response.reasonPhrase}');
    }
    return body;
  }
}

class ApiException implements Exception {
  ApiException(this.message);
  final String message;
  @override
  String toString() => message;
}

class TaskItem {
  TaskItem({
    required this.id,
    required this.title,
    required this.remindTime,
    required this.nextRemindTime,
    required this.status,
    required this.remindIntervalMinutes,
    required this.remindCount,
    required this.category,
    this.content,
    this.rawInput,
    this.completedAt,
    this.cancelledAt,
  });

  final int id;
  final String title;
  final String? content;
  final String? rawInput;
  final DateTime remindTime;
  final DateTime nextRemindTime;
  final String status;
  final int remindIntervalMinutes;
  final int remindCount;
  final String category;
  final DateTime? completedAt;
  final DateTime? cancelledAt;

  bool get active => status != 'done' && status != 'cancelled';
  bool get handled => !active;

  String get statusLabel => switch (status) {
        'done' => '已完成',
        'cancelled' => '已取消',
        'reminding' => '提醒中',
        'postponed' => '已延后',
        _ => '待处理',
      };

  factory TaskItem.fromJson(Map<String, dynamic> json) {
    return TaskItem(
      id: json['id'] as int,
      title: json['title'] as String,
      content: json['content'] as String?,
      rawInput: json['raw_input'] as String?,
      category: ((json['category'] as String?) ?? '默认').trim().isEmpty
          ? '默认'
          : (json['category'] as String),
      remindTime: DateTime.parse(json['remind_time'] as String),
      nextRemindTime: DateTime.parse(json['next_remind_time'] as String),
      status: json['status'] as String,
      remindIntervalMinutes: json['remind_interval_minutes'] as int,
      remindCount: json['remind_count'] as int,
      completedAt: _parseNullableDate(json['completed_at']),
      cancelledAt: _parseNullableDate(json['cancelled_at']),
    );
  }
}

DateTime? _parseNullableDate(Object? value) {
  if (value == null) return null;
  return DateTime.parse(value as String);
}

class TaskDetail extends TaskItem {
  TaskDetail({
    required super.id,
    required super.title,
    required super.remindTime,
    required super.nextRemindTime,
    required super.status,
    required super.remindIntervalMinutes,
    required super.remindCount,
    required super.category,
    required this.logs,
    super.content,
    super.rawInput,
    super.completedAt,
    super.cancelledAt,
  });

  final List<ReminderLog> logs;

  factory TaskDetail.fromJson(Map<String, dynamic> json) {
    final base = TaskItem.fromJson(json);
    return TaskDetail(
      id: base.id,
      title: base.title,
      content: base.content,
      rawInput: base.rawInput,
      remindTime: base.remindTime,
      nextRemindTime: base.nextRemindTime,
      status: base.status,
      remindIntervalMinutes: base.remindIntervalMinutes,
      remindCount: base.remindCount,
      category: base.category,
      completedAt: base.completedAt,
      cancelledAt: base.cancelledAt,
      logs: ((json['remind_logs'] ?? []) as List)
          .map((item) => ReminderLog.fromJson(item as Map<String, dynamic>))
          .toList(),
    );
  }
}

class ReminderLog {
  ReminderLog({
    required this.channel,
    required this.message,
    required this.result,
    required this.createdAt,
    this.errorMessage,
  });

  final String channel;
  final String message;
  final String result;
  final String? errorMessage;
  final DateTime createdAt;

  factory ReminderLog.fromJson(Map<String, dynamic> json) {
    return ReminderLog(
      channel: json['channel'] as String,
      message: json['message'] as String,
      result: json['result'] as String,
      errorMessage: json['error_message'] as String?,
      createdAt: DateTime.parse(json['created_at'] as String),
    );
  }
}

class NotionImportResult {
  NotionImportResult({
    required this.created,
    required this.updated,
    required this.skipped,
    required this.failed,
    required this.errors,
  });

  final int created;
  final int updated;
  final int skipped;
  final int failed;
  final List<String> errors;

  factory NotionImportResult.fromJson(Map<String, dynamic> json) {
    return NotionImportResult(
      created: (json['created'] as num?)?.toInt() ?? 0,
      updated: (json['updated'] as num?)?.toInt() ?? 0,
      skipped: (json['skipped'] as num?)?.toInt() ?? 0,
      failed: (json['failed'] as num?)?.toInt() ?? 0,
      errors: ((json['errors'] ?? []) as List)
          .map((item) {
            final data = item as Map<String, dynamic>;
            final title = data['title'] as String?;
            final message = data['message'] as String? ?? '未知错误';
            return title == null || title.isEmpty ? message : '$title：$message';
          })
          .cast<String>()
          .toList(),
    );
  }
}

class AppSettings {
  AppSettings({
    this.dingdingWebhook,
    this.dingdingSecret,
    this.notionToken,
    this.notionDataSourceId,
    this.notionTitleProperty = 'Name',
    this.notionRemindTimeProperty = '提醒时间',
    this.notionContentProperty = '内容',
    this.notionCategoryProperty = '分类',
    this.notionIntervalProperty = '提醒间隔',
    this.notionStatusProperty = '状态',
    this.notionCreatedTimeProperty = '创建时间',
    this.enableNotionSync = false,
    this.notionSyncIntervalMinutes = 5,
    this.notionLastSyncedAt,
    this.defaultRemindIntervalMinutes = 10,
    this.enableDingding = true,
    this.enableAppNotify = true,
    this.enableCalendar = false,
  });

  final String? dingdingWebhook;
  final String? dingdingSecret;
  final String? notionToken;
  final String? notionDataSourceId;
  final String notionTitleProperty;
  final String notionRemindTimeProperty;
  final String notionContentProperty;
  final String notionCategoryProperty;
  final String notionIntervalProperty;
  final String notionStatusProperty;
  final String notionCreatedTimeProperty;
  final bool enableNotionSync;
  final int notionSyncIntervalMinutes;
  final DateTime? notionLastSyncedAt;
  final int defaultRemindIntervalMinutes;
  final bool enableDingding;
  final bool enableAppNotify;
  final bool enableCalendar;

  factory AppSettings.fromJson(Map<String, dynamic> json) {
    return AppSettings(
      dingdingWebhook: json['dingding_webhook'] as String?,
      dingdingSecret: json['dingding_secret'] as String?,
      notionToken: json['notion_token'] as String?,
      notionDataSourceId: json['notion_data_source_id'] as String?,
      notionTitleProperty:
          _jsonStringOrDefault(json['notion_title_property'], 'Name'),
      notionRemindTimeProperty:
          _jsonStringOrDefault(json['notion_remind_time_property'], '提醒时间'),
      notionContentProperty:
          _jsonStringOrDefault(json['notion_content_property'], '内容'),
      notionCategoryProperty:
          _jsonStringOrDefault(json['notion_category_property'], '分类'),
      notionIntervalProperty:
          _jsonStringOrDefault(json['notion_interval_property'], '提醒间隔'),
      notionStatusProperty:
          _jsonStringOrDefault(json['notion_status_property'], '状态'),
      notionCreatedTimeProperty:
          _jsonStringOrDefault(json['notion_created_time_property'], '创建时间'),
      enableNotionSync: json['enable_notion_sync'] == 1,
      notionSyncIntervalMinutes:
          (json['notion_sync_interval_minutes'] as int?) ?? 5,
      notionLastSyncedAt: _parseNullableDate(json['notion_last_synced_at']),
      defaultRemindIntervalMinutes:
          json['default_remind_interval_minutes'] as int,
      enableDingding: json['enable_dingding'] == 1,
      enableAppNotify: json['enable_app_notify'] == 1,
      enableCalendar: json['enable_calendar'] == 1,
    );
  }

  Map<String, dynamic> toJson() => {
        'dingding_webhook': dingdingWebhook,
        'dingding_secret': dingdingSecret,
        'notion_token': notionToken,
        'notion_data_source_id': notionDataSourceId,
        'notion_title_property': notionTitleProperty,
        'notion_remind_time_property': notionRemindTimeProperty,
        'notion_content_property': notionContentProperty,
        'notion_category_property': notionCategoryProperty,
        'notion_interval_property': notionIntervalProperty,
        'notion_status_property': notionStatusProperty,
        'notion_created_time_property': notionCreatedTimeProperty,
        'enable_notion_sync': enableNotionSync,
        'notion_sync_interval_minutes': notionSyncIntervalMinutes,
        'default_remind_interval_minutes': defaultRemindIntervalMinutes,
        'enable_dingding': enableDingding,
        'enable_app_notify': enableAppNotify,
        'enable_calendar': enableCalendar,
      };
}

String _jsonStringOrDefault(Object? value, String fallback) {
  if (value is String && value.trim().isNotEmpty) {
    return value;
  }
  return fallback;
}

class TaskHomePage extends StatefulWidget {
  const TaskHomePage({super.key});

  @override
  State<TaskHomePage> createState() => _TaskHomePageState();
}

enum TaskLayoutMode { list, gallery }

enum TaskEditFocus { title, content, category, remindTime, interval }

class _TaskHomePageState extends State<TaskHomePage> {
  late final TextEditingController apiUrlController;
  late ApiClient api;
  List<TaskItem> tasks = [];
  bool loading = true;
  bool syncingNotion = false;
  String? error;
  Timer? timer;
  int pageIndex = 0;
  String selectedCategory = '全部';
  TaskLayoutMode taskLayoutMode = TaskLayoutMode.list;

  @override
  void initState() {
    super.initState();
    final defaultApiUrl = _defaultApiBaseUrl();
    apiUrlController = TextEditingController(text: defaultApiUrl);
    api = ApiClient(defaultApiUrl);
    refresh();
    timer = Timer.periodic(
        const Duration(seconds: 15), (_) => refresh(silent: true));
  }

  @override
  void dispose() {
    timer?.cancel();
    apiUrlController.dispose();
    super.dispose();
  }

  Future<void> refresh({bool silent = false}) async {
    if (!silent) {
      setState(() {
        loading = true;
        error = null;
      });
    }
    try {
      final data = await api.listTasks();
      setState(() {
        tasks = data;
        loading = false;
        error = null;
      });
    } catch (e) {
      setState(() {
        loading = false;
        error = '$e';
      });
    }
  }

  void applyApiUrl() {
    api = ApiClient(apiUrlController.text.trim().replaceAll(RegExp(r'/$'), ''));
    refresh();
  }

  Future<void> runAction(Future<void> Function() action) async {
    try {
      await action();
      await refresh(silent: true);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final wide = MediaQuery.sizeOf(context).width >= 820;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Personal Helper'),
        actions: [
          IconButton(
              tooltip: '刷新',
              onPressed: refresh,
              icon: const Icon(Icons.refresh)),
        ],
      ),
      floatingActionButton: _buildFloatingActions(),
      bottomNavigationBar: wide
          ? null
          : NavigationBar(
              selectedIndex: pageIndex,
              onDestinationSelected: (index) =>
                  setState(() => pageIndex = index),
              destinations: const [
                NavigationDestination(icon: Icon(Icons.checklist), label: '任务'),
                NavigationDestination(
                    icon: Icon(Icons.calendar_month_outlined), label: '日历'),
                NavigationDestination(icon: Icon(Icons.tune), label: '设置'),
              ],
            ),
      body: SafeArea(
        child: Row(
          children: [
            if (wide)
              NavigationRail(
                selectedIndex: pageIndex,
                onDestinationSelected: (index) =>
                    setState(() => pageIndex = index),
                labelType: NavigationRailLabelType.all,
                destinations: const [
                  NavigationRailDestination(
                      icon: Icon(Icons.checklist), label: Text('任务')),
                  NavigationRailDestination(
                      icon: Icon(Icons.calendar_month_outlined),
                      label: Text('日历')),
                  NavigationRailDestination(
                      icon: Icon(Icons.tune), label: Text('设置')),
                ],
              ),
            Expanded(
              child: Column(
                children: [
                  ApiConnectionBar(
                    controller: apiUrlController,
                    onConnect: applyApiUrl,
                    connected: error == null,
                  ),
                  Expanded(child: _buildCurrentPage()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCurrentPage() {
    if (loading) {
      return const Center(child: CircularProgressIndicator());
    }
    if (error != null) {
      return ConnectionErrorView(
        error: error!,
        onRetry: refresh,
      );
    }
    return switch (pageIndex) {
      1 => CalendarPlannerPage(
          tasks: tasks,
          onRefresh: refresh,
          onOpenTask: _openTask,
          onDone: (task) => runAction(() async => api.done(task.id)),
          onCancel: (task) => runAction(() async => api.cancel(task.id)),
          onPostpone: (task, minutes) =>
              runAction(() async => api.postpone(task.id, minutes)),
        ),
      2 => SettingsPage(api: api, embedded: true),
      _ => TaskListPage(
          tasks: tasks,
          selectedCategory: selectedCategory,
          onCategorySelected: (category) =>
              setState(() => selectedCategory = category),
          layoutMode: taskLayoutMode,
          onLayoutModeChanged: (mode) => setState(() => taskLayoutMode = mode),
          onRefresh: refresh,
          onOpenTask: _openTask,
          onDone: (task) => runAction(() async => api.done(task.id)),
          onCancel: (task) => runAction(() async => api.cancel(task.id)),
          onPostpone: (task, minutes) =>
              runAction(() async => api.postpone(task.id, minutes)),
        ),
    };
  }

  Future<void> _openTask(TaskItem task) {
    return Navigator.of(context)
        .push(MaterialPageRoute(
            builder: (_) => TaskDetailPage(api: api, taskId: task.id)))
        .then((_) => refresh(silent: true));
  }

  Widget? _buildFloatingActions() {
    if (pageIndex == 2) {
      return FloatingActionButton(
        tooltip: '同步 Notion',
        onPressed: syncingNotion ? null : syncNotionNow,
        child: syncingNotion
            ? const SizedBox(
                width: 22,
                height: 22,
                child: CircularProgressIndicator(strokeWidth: 2),
              )
            : const Icon(Icons.sync),
      );
    }
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        FloatingActionButton.small(
          heroTag: 'sync-notion',
          tooltip: '同步 Notion',
          onPressed: syncingNotion ? null : syncNotionNow,
          child: syncingNotion
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.sync),
        ),
        const SizedBox(height: 10),
        FloatingActionButton.extended(
          heroTag: 'create-task',
          onPressed: () => Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => CreateTaskPage(api: api)))
              .then((_) => refresh(silent: true)),
          icon: const Icon(Icons.add),
          label: const Text('新增任务'),
        ),
      ],
    );
  }

  Future<void> syncNotionNow() async {
    setState(() => syncingNotion = true);
    try {
      final settings = await api.getSettings();
      if ((settings.notionToken ?? '').isEmpty ||
          (settings.notionDataSourceId ?? '').isEmpty) {
        throw ApiException('请先到设置页填写并保存 Notion Token 和数据库/数据源 ID');
      }
      final result = await api.importNotionTasks(
        notionToken: settings.notionToken!,
        dataSourceId: settings.notionDataSourceId!,
        titleProperty: settings.notionTitleProperty,
        remindTimeProperty: settings.notionRemindTimeProperty,
        contentProperty: settings.notionContentProperty,
        categoryProperty: settings.notionCategoryProperty,
        intervalProperty: settings.notionIntervalProperty,
        statusProperty: settings.notionStatusProperty,
        createdTimeProperty: settings.notionCreatedTimeProperty,
        defaultIntervalMinutes: settings.defaultRemindIntervalMinutes,
      );
      await refresh(silent: true);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
              'Notion 同步完成：新增 ${result.created}，更新 ${result.updated}，跳过 ${result.skipped}，失败 ${result.failed}'),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('同步失败：$e')));
    } finally {
      if (mounted) {
        setState(() => syncingNotion = false);
      }
    }
  }
}

String _defaultApiBaseUrl() {
  final host = Uri.base.host;
  final apiHost = host.isEmpty || host == 'localhost' ? '127.0.0.1' : host;
  return 'http://$apiHost:8000';
}

class ApiConnectionBar extends StatelessWidget {
  const ApiConnectionBar({
    required this.controller,
    required this.onConnect,
    required this.connected,
    super.key,
  });

  final TextEditingController controller;
  final VoidCallback onConnect;
  final bool connected;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      decoration: BoxDecoration(
        color: colors.surface,
        border: Border(bottom: BorderSide(color: colors.outlineVariant)),
      ),
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                connected
                    ? Icons.cloud_done_outlined
                    : Icons.cloud_off_outlined,
                color: connected ? Colors.teal : colors.error,
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: controller,
                  decoration: const InputDecoration(
                    labelText: '后端地址',
                    isDense: true,
                  ),
                  onSubmitted: (_) => onConnect(),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filledTonal(
                tooltip: '连接',
                onPressed: onConnect,
                icon: const Icon(Icons.link),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            connected ? '已连接到后端，任务会自动刷新' : '未连接，手机端请使用 Mac/电脑的局域网 IP',
            style: TextStyle(
              fontSize: 12,
              color: connected ? colors.primary : colors.error,
            ),
          ),
        ],
      ),
    );
  }
}

class ConnectionErrorView extends StatelessWidget {
  const ConnectionErrorView(
      {required this.error, required this.onRetry, super.key});

  final String error;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: colors.errorContainer.withValues(alpha: 0.45),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: colors.error.withValues(alpha: 0.25)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.cloud_off_outlined, color: colors.error, size: 36),
              const SizedBox(height: 10),
              Text('后端连接失败',
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Text(error, textAlign: TextAlign.center),
              const SizedBox(height: 14),
              FilledButton.icon(
                onPressed: onRetry,
                icon: const Icon(Icons.refresh),
                label: const Text('重试连接'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class TaskListPage extends StatelessWidget {
  const TaskListPage({
    required this.tasks,
    required this.selectedCategory,
    required this.onCategorySelected,
    required this.layoutMode,
    required this.onLayoutModeChanged,
    required this.onRefresh,
    required this.onOpenTask,
    required this.onDone,
    required this.onCancel,
    required this.onPostpone,
    super.key,
  });

  final List<TaskItem> tasks;
  final String selectedCategory;
  final ValueChanged<String> onCategorySelected;
  final TaskLayoutMode layoutMode;
  final ValueChanged<TaskLayoutMode> onLayoutModeChanged;
  final Future<void> Function({bool silent}) onRefresh;
  final ValueChanged<TaskItem> onOpenTask;
  final ValueChanged<TaskItem> onDone;
  final ValueChanged<TaskItem> onCancel;
  final void Function(TaskItem task, int minutes) onPostpone;

  @override
  Widget build(BuildContext context) {
    final categories = [
      '全部',
      ...{for (final task in tasks) task.category}
    ];
    final filteredTasks = selectedCategory == '全部'
        ? tasks
        : tasks.where((task) => task.category == selectedCategory).toList();
    final activeTasks = filteredTasks.where((task) => task.active).toList();
    final completedTasks =
        filteredTasks.where((task) => task.status == 'done').toList();
    final active = activeTasks.length;
    final handled = completedTasks.length;
    if (tasks.isEmpty) {
      return const EmptyState(
        icon: Icons.inbox_outlined,
        title: '暂无任务',
        message: '点右下角新增任务，或者用一句话创建提醒。',
      );
    }
    return RefreshIndicator(
      onRefresh: () => onRefresh(),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
        children: [
          TaskSummary(
              active: active, handled: handled, total: active + handled),
          const SizedBox(height: 12),
          CategoryFilterBar(
            categories: categories,
            selectedCategory: selectedCategory,
            onSelected: onCategorySelected,
          ),
          const SizedBox(height: 12),
          TaskLayoutSwitch(
            mode: layoutMode,
            onChanged: onLayoutModeChanged,
          ),
          const SizedBox(height: 12),
          if (filteredTasks.isEmpty)
            const EmptyState(
              icon: Icons.label_off_outlined,
              title: '这个分类暂时没有任务',
              message: '切换分类，或新建任务时选择这个标签。',
            )
          else if (layoutMode == TaskLayoutMode.list) ...[
            if (activeTasks.isEmpty)
              const EmptyState(
                icon: Icons.task_alt,
                title: '当前没有进行中的提醒',
                message: '已完成的任务可以在下面展开查看。',
              )
            else
              for (final task in activeTasks) ...[
                TaskTile(
                  task: task,
                  onTap: () => onOpenTask(task),
                  onDone: () => onDone(task),
                  onCancel: () => onCancel(task),
                  onPostpone: (minutes) => onPostpone(task, minutes),
                ),
                const SizedBox(height: 8),
              ],
            if (completedTasks.isNotEmpty) ...[
              const SizedBox(height: 8),
              CompletedTasksSection(
                tasks: completedTasks,
                onOpenTask: onOpenTask,
              ),
            ],
          ] else
            LayoutBuilder(
              builder: (context, constraints) {
                final width = constraints.maxWidth;
                final columns = width >= 980
                    ? 4
                    : width >= 680
                        ? 3
                        : 2;
                return GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: activeTasks.length,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: columns,
                    mainAxisSpacing: 10,
                    crossAxisSpacing: 10,
                    childAspectRatio: columns == 2 ? 0.92 : 1.02,
                  ),
                  itemBuilder: (context, index) {
                    final task = activeTasks[index];
                    return TaskGalleryCard(
                      task: task,
                      onTap: () => onOpenTask(task),
                      onDone: () => onDone(task),
                      onCancel: () => onCancel(task),
                      onPostpone: (minutes) => onPostpone(task, minutes),
                    );
                  },
                );
              },
            ),
        ],
      ),
    );
  }
}

class TaskLayoutSwitch extends StatelessWidget {
  const TaskLayoutSwitch({
    required this.mode,
    required this.onChanged,
    super.key,
  });

  final TaskLayoutMode mode;
  final ValueChanged<TaskLayoutMode> onChanged;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Row(
      children: [
        Expanded(
          child: Text(
            '显示方式',
            style: Theme.of(context)
                .textTheme
                .labelLarge
                ?.copyWith(color: colors.onSurfaceVariant),
          ),
        ),
        SegmentedButton<TaskLayoutMode>(
          segments: const [
            ButtonSegment(
              value: TaskLayoutMode.list,
              icon: Icon(Icons.view_agenda_outlined),
              label: Text('列表', softWrap: false),
            ),
            ButtonSegment(
              value: TaskLayoutMode.gallery,
              icon: Icon(Icons.grid_view_outlined),
              label: Text('画廊', softWrap: false),
            ),
          ],
          selected: {mode},
          onSelectionChanged: (value) => onChanged(value.first),
          showSelectedIcon: false,
          style: ButtonStyle(
            minimumSize: const WidgetStatePropertyAll(Size(84, 44)),
            padding: const WidgetStatePropertyAll(
              EdgeInsets.symmetric(horizontal: 14),
            ),
            textStyle: WidgetStatePropertyAll(
              Theme.of(context).textTheme.labelLarge,
            ),
            visualDensity: VisualDensity.standard,
          ),
        ),
      ],
    );
  }
}

class CompletedTasksSection extends StatelessWidget {
  const CompletedTasksSection({
    required this.tasks,
    required this.onOpenTask,
    super.key,
  });

  final List<TaskItem> tasks;
  final ValueChanged<TaskItem> onOpenTask;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: colors.outlineVariant),
      ),
      child: ExpansionTile(
        initiallyExpanded: false,
        leading: const Icon(Icons.task_alt),
        title: Text('已完成 (${tasks.length})'),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        collapsedShape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(8)),
        ),
        children: [
          for (final task in tasks)
            ListTile(
              dense: true,
              leading: const Icon(Icons.check_circle_outline),
              title: Text(
                task.title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              subtitle: Text(DateFormat('MM-dd HH:mm').format(task.remindTime)),
              onTap: () => onOpenTask(task),
            ),
        ],
      ),
    );
  }
}

class CategoryFilterBar extends StatelessWidget {
  const CategoryFilterBar({
    required this.categories,
    required this.selectedCategory,
    required this.onSelected,
    super.key,
  });

  final List<String> categories;
  final String selectedCategory;
  final ValueChanged<String> onSelected;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 48,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: categories.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final category = categories[index];
          return CategoryPill(
            selected: category == selectedCategory,
            label: category,
            onTap: () => onSelected(category),
          );
        },
      ),
    );
  }
}

class CategoryPill extends StatelessWidget {
  const CategoryPill({
    required this.selected,
    required this.label,
    required this.onTap,
    super.key,
  });

  final bool selected;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Material(
        color: selected
            ? colors.primaryContainer
            : colors.surfaceContainerHighest.withValues(alpha: 0.35),
        borderRadius: BorderRadius.circular(8),
        child: InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: onTap,
          child: Container(
            height: 42,
            constraints: const BoxConstraints(minWidth: 74),
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              border: Border.all(
                color: selected ? Colors.transparent : colors.outlineVariant,
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  selected ? Icons.check_circle_outline : Icons.label_outline,
                  size: 18,
                  color: selected ? colors.primary : colors.onSurfaceVariant,
                ),
                const SizedBox(width: 8),
                Text(
                  label,
                  maxLines: 1,
                  softWrap: false,
                  overflow: TextOverflow.visible,
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                        color: selected
                            ? colors.onPrimaryContainer
                            : colors.onSurface,
                        height: 1.1,
                      ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class TaskSummary extends StatelessWidget {
  const TaskSummary(
      {required this.active,
      required this.handled,
      required this.total,
      super.key});

  final int active;
  final int handled;
  final int total;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
            child: SummaryTile(
                label: '待处理', value: '$active', icon: Icons.pending_actions)),
        const SizedBox(width: 8),
        Expanded(
            child: SummaryTile(
                label: '已处理', value: '$handled', icon: Icons.task_alt)),
        const SizedBox(width: 8),
        Expanded(
            child: SummaryTile(
                label: '全部', value: '$total', icon: Icons.list_alt)),
      ],
    );
  }
}

class SummaryTile extends StatelessWidget {
  const SummaryTile(
      {required this.label,
      required this.value,
      required this.icon,
      super.key});

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        border: Border.all(color: colors.outlineVariant),
        borderRadius: BorderRadius.circular(8),
        color: colors.surfaceContainerHighest.withValues(alpha: 0.35),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 20, color: colors.primary),
          const SizedBox(height: 4),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              value,
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
          ),
          FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(label, style: Theme.of(context).textTheme.labelMedium),
          ),
        ],
      ),
    );
  }
}

class CalendarPlannerPage extends StatefulWidget {
  const CalendarPlannerPage({
    required this.tasks,
    required this.onRefresh,
    required this.onOpenTask,
    required this.onDone,
    required this.onCancel,
    required this.onPostpone,
    super.key,
  });

  final List<TaskItem> tasks;
  final Future<void> Function({bool silent}) onRefresh;
  final ValueChanged<TaskItem> onOpenTask;
  final ValueChanged<TaskItem> onDone;
  final ValueChanged<TaskItem> onCancel;
  final void Function(TaskItem task, int minutes) onPostpone;

  @override
  State<CalendarPlannerPage> createState() => _CalendarPlannerPageState();
}

class _CalendarPlannerPageState extends State<CalendarPlannerPage> {
  late DateTime focusedMonth =
      DateTime(DateTime.now().year, DateTime.now().month);
  late DateTime selectedDate = _dateOnly(DateTime.now());

  @override
  Widget build(BuildContext context) {
    final selectedTasks = widget.tasks
        .where((task) => _sameDay(task.remindTime, selectedDate))
        .toList();
    final activeCount = selectedTasks.where((task) => task.active).length;
    final handledCount = selectedTasks.length - activeCount;

    return RefreshIndicator(
      onRefresh: () => widget.onRefresh(),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
        children: [
          _CalendarHeader(
            focusedMonth: focusedMonth,
            onPrevious: () => setState(() {
              focusedMonth =
                  DateTime(focusedMonth.year, focusedMonth.month - 1);
              selectedDate = DateTime(focusedMonth.year, focusedMonth.month, 1);
            }),
            onNext: () => setState(() {
              focusedMonth =
                  DateTime(focusedMonth.year, focusedMonth.month + 1);
              selectedDate = DateTime(focusedMonth.year, focusedMonth.month, 1);
            }),
          ),
          const SizedBox(height: 8),
          MonthGrid(
            month: focusedMonth,
            selectedDate: selectedDate,
            tasks: widget.tasks,
            onSelect: (date) => setState(() => selectedDate = date),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                  child: SummaryTile(
                      label: '当天待处理',
                      value: '$activeCount',
                      icon: Icons.pending_actions)),
              const SizedBox(width: 8),
              Expanded(
                  child: SummaryTile(
                      label: '当天已处理',
                      value: '$handledCount',
                      icon: Icons.task_alt)),
            ],
          ),
          const SizedBox(height: 14),
          Text(
            '${DateFormat('yyyy年MM月dd日').format(selectedDate)} 计划',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 8),
          if (selectedTasks.isEmpty)
            const Padding(
              padding: EdgeInsets.only(top: 24),
              child: EmptyState(
                icon: Icons.event_available_outlined,
                title: '这天还没有任务',
                message: '可以把想处理的事安排到这一天。',
              ),
            )
          else
            for (final task in selectedTasks) ...[
              TaskTile(
                task: task,
                onTap: () => widget.onOpenTask(task),
                onDone: () => widget.onDone(task),
                onCancel: () => widget.onCancel(task),
                onPostpone: (minutes) => widget.onPostpone(task, minutes),
                compact: true,
              ),
              const SizedBox(height: 8),
            ],
        ],
      ),
    );
  }
}

class _CalendarHeader extends StatelessWidget {
  const _CalendarHeader({
    required this.focusedMonth,
    required this.onPrevious,
    required this.onNext,
  });

  final DateTime focusedMonth;
  final VoidCallback onPrevious;
  final VoidCallback onNext;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(
            tooltip: '上个月',
            onPressed: onPrevious,
            icon: const Icon(Icons.chevron_left)),
        Expanded(
          child: Center(
            child: Text(
              DateFormat('yyyy年MM月').format(focusedMonth),
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
          ),
        ),
        IconButton(
            tooltip: '下个月',
            onPressed: onNext,
            icon: const Icon(Icons.chevron_right)),
      ],
    );
  }
}

class MonthGrid extends StatelessWidget {
  const MonthGrid({
    required this.month,
    required this.selectedDate,
    required this.tasks,
    required this.onSelect,
    super.key,
  });

  final DateTime month;
  final DateTime selectedDate;
  final List<TaskItem> tasks;
  final ValueChanged<DateTime> onSelect;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final firstDay = DateTime(month.year, month.month, 1);
    final daysInMonth = DateTime(month.year, month.month + 1, 0).day;
    final leading = firstDay.weekday % 7;
    final totalCells = ((leading + daysInMonth + 6) ~/ 7) * 7;

    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: colors.outlineVariant),
        borderRadius: BorderRadius.circular(8),
      ),
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          Row(
            children: const ['日', '一', '二', '三', '四', '五', '六']
                .map((day) => Expanded(child: Center(child: Text(day))))
                .toList(),
          ),
          const SizedBox(height: 6),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 7,
              mainAxisSpacing: 6,
              crossAxisSpacing: 6,
              childAspectRatio: 0.68,
            ),
            itemCount: totalCells,
            itemBuilder: (context, index) {
              final day = index - leading + 1;
              if (day < 1 || day > daysInMonth) {
                return const SizedBox.shrink();
              }
              final date = DateTime(month.year, month.month, day);
              final dayTasks = tasks
                  .where((task) => _sameDay(task.remindTime, date))
                  .toList();
              final active = dayTasks.where((task) => task.active).length;
              final handled = dayTasks.length - active;
              final selected = _sameDay(date, selectedDate);
              final today = _sameDay(date, DateTime.now());

              return InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: () => onSelect(date),
                child: Container(
                  decoration: BoxDecoration(
                    color: selected
                        ? colors.primaryContainer
                        : colors.surfaceContainerHighest
                            .withValues(alpha: 0.28),
                    borderRadius: BorderRadius.circular(8),
                    border: today
                        ? Border.all(color: colors.primary, width: 1.5)
                        : null,
                  ),
                  padding:
                      const EdgeInsets.symmetric(horizontal: 4, vertical: 5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        '$day',
                        style: TextStyle(
                          fontWeight: selected || today
                              ? FontWeight.w700
                              : FontWeight.w500,
                          color: selected ? colors.onPrimaryContainer : null,
                        ),
                      ),
                      if (dayTasks.isNotEmpty)
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 2),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                for (final task in dayTasks.take(2))
                                  Text(
                                    task.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: TextStyle(
                                      fontSize: 9,
                                      height: 1.05,
                                      color: selected
                                          ? colors.onPrimaryContainer
                                          : colors.onSurfaceVariant,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        )
                      else
                        const Spacer(),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          if (active > 0)
                            _CountDot(
                                label: '$active', color: Colors.deepOrange),
                          if (active > 0 && handled > 0)
                            const SizedBox(width: 3),
                          if (handled > 0)
                            _CountDot(label: '$handled', color: Colors.teal),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}

class _CountDot extends StatelessWidget {
  const _CountDot({required this.label, required this.color});

  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
      padding: const EdgeInsets.symmetric(horizontal: 3),
      decoration:
          BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
      alignment: Alignment.center,
      child: Text(label,
          style: const TextStyle(
              color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700)),
    );
  }
}

class EmptyState extends StatelessWidget {
  const EmptyState(
      {required this.icon,
      required this.title,
      required this.message,
      super.key});

  final IconData icon;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 42, color: colors.primary),
            const SizedBox(height: 10),
            Text(title,
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(fontWeight: FontWeight.w700)),
            const SizedBox(height: 4),
            Text(message,
                textAlign: TextAlign.center,
                style: TextStyle(color: colors.onSurfaceVariant)),
          ],
        ),
      ),
    );
  }
}

DateTime _dateOnly(DateTime value) =>
    DateTime(value.year, value.month, value.day);

bool _sameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

class TaskTile extends StatelessWidget {
  const TaskTile({
    required this.task,
    required this.onTap,
    required this.onDone,
    required this.onCancel,
    required this.onPostpone,
    this.compact = false,
    super.key,
  });

  final TaskItem task;
  final VoidCallback onTap;
  final VoidCallback onDone;
  final VoidCallback onCancel;
  final ValueChanged<int> onPostpone;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final formatter = DateFormat('MM-dd HH:mm');
    final overdue = task.active && task.nextRemindTime.isBefore(DateTime.now());
    final statusColor = taskStatusColor(task);
    final colors = Theme.of(context).colorScheme;
    return Container(
      decoration: BoxDecoration(
        color: colors.surface,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: overdue
              ? Colors.deepOrange.withValues(alpha: 0.55)
              : colors.outlineVariant,
        ),
        boxShadow: [
          BoxShadow(
            color: colors.shadow.withValues(alpha: 0.04),
            blurRadius: 10,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      task.title,
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(fontWeight: FontWeight.w700),
                    ),
                  ),
                  Chip(
                    visualDensity: VisualDensity.compact,
                    label: SizedBox(
                      width: 48,
                      child: Center(
                        child: Text(
                          task.statusLabel,
                          maxLines: 1,
                          overflow: TextOverflow.fade,
                          softWrap: false,
                        ),
                      ),
                    ),
                    side: BorderSide.none,
                    color: WidgetStatePropertyAll(
                        statusColor.withValues(alpha: 0.14)),
                    labelStyle: TextStyle(color: statusColor),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Icon(
                    overdue
                        ? Icons.warning_amber_outlined
                        : Icons.notifications_active_outlined,
                    size: 17,
                    color: overdue ? Colors.deepOrange : null,
                  ),
                  const SizedBox(width: 6),
                  Expanded(
                      child: Text(
                    '${overdue ? '已到点' : '下次提醒'}：${formatter.format(task.nextRemindTime)}',
                    style: TextStyle(
                      color: overdue ? Colors.deepOrange : null,
                      fontWeight: overdue ? FontWeight.w700 : FontWeight.w400,
                    ),
                  )),
                  Text('已提醒 ${task.remindCount} 次',
                      style: TextStyle(color: colors.onSurfaceVariant)),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Icon(Icons.label_outline, size: 16, color: colors.primary),
                  const SizedBox(width: 5),
                  Text(task.category,
                      style: TextStyle(
                          color: colors.primary, fontWeight: FontWeight.w600)),
                ],
              ),
              if ((task.content ?? '').isNotEmpty) ...[
                const SizedBox(height: 6),
                Text(
                  task.content!,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color: colors.onSurfaceVariant),
                ),
              ],
              if (!compact) ...[
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    FilledButton.tonalIcon(
                      onPressed: task.active ? onDone : null,
                      icon: const Icon(Icons.check),
                      label: const Text('完成'),
                    ),
                    OutlinedButton.icon(
                      onPressed: task.active ? () => onPostpone(10) : null,
                      icon: const Icon(Icons.snooze),
                      label: const Text('10分钟'),
                    ),
                    OutlinedButton.icon(
                      onPressed: task.active ? () => onPostpone(30) : null,
                      icon: const Icon(Icons.more_time),
                      label: const Text('30分钟'),
                    ),
                    OutlinedButton.icon(
                      onPressed: task.active ? () => onPostpone(60) : null,
                      icon: const Icon(Icons.schedule),
                      label: const Text('1小时'),
                    ),
                    OutlinedButton.icon(
                      onPressed: task.active ? onCancel : null,
                      icon: const Icon(Icons.close),
                      label: const Text('取消'),
                    ),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

Color taskStatusColor(TaskItem task) {
  return switch (task.status) {
    'done' => Colors.green,
    'cancelled' => Colors.grey,
    'reminding' => Colors.deepOrange,
    'postponed' => Colors.indigo,
    _ => Colors.teal,
  };
}

IconData taskStatusIcon(TaskItem task) {
  return switch (task.status) {
    'done' => Icons.task_alt,
    'cancelled' => Icons.block,
    'reminding' => Icons.notifications_active_outlined,
    'postponed' => Icons.snooze,
    _ => Icons.pending_actions,
  };
}

class TaskGalleryCard extends StatelessWidget {
  const TaskGalleryCard({
    required this.task,
    required this.onTap,
    required this.onDone,
    required this.onCancel,
    required this.onPostpone,
    super.key,
  });

  final TaskItem task;
  final VoidCallback onTap;
  final VoidCallback onDone;
  final VoidCallback onCancel;
  final ValueChanged<int> onPostpone;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final formatter = DateFormat('MM-dd HH:mm');
    final overdue = task.active && task.nextRemindTime.isBefore(DateTime.now());
    final statusColor = taskStatusColor(task);
    return Material(
      color: colors.surface,
      borderRadius: BorderRadius.circular(8),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(
              color: overdue
                  ? Colors.deepOrange.withValues(alpha: 0.55)
                  : colors.outlineVariant,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: statusColor.withValues(alpha: 0.13),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(taskStatusIcon(task), color: statusColor),
                  ),
                  const Spacer(),
                  IconButton(
                    tooltip: '延期10分钟',
                    visualDensity: VisualDensity.compact,
                    onPressed: task.active ? () => onPostpone(10) : null,
                    icon: const Icon(Icons.snooze),
                  ),
                ],
              ),
              const SizedBox(height: 10),
              Text(
                task.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: Theme.of(context)
                    .textTheme
                    .titleSmall
                    ?.copyWith(fontWeight: FontWeight.w800),
              ),
              const Spacer(),
              Row(
                children: [
                  Icon(
                    overdue
                        ? Icons.warning_amber_outlined
                        : Icons.schedule_outlined,
                    size: 16,
                    color: overdue ? Colors.deepOrange : colors.primary,
                  ),
                  const SizedBox(width: 5),
                  Expanded(
                    child: Text(
                      formatter.format(task.nextRemindTime),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                        color: overdue ? Colors.deepOrange : null,
                        fontWeight: overdue ? FontWeight.w700 : FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                children: [
                  Expanded(
                    child: Chip(
                      visualDensity: VisualDensity.compact,
                      label: Text(task.statusLabel),
                      side: BorderSide.none,
                      color: WidgetStatePropertyAll(
                          statusColor.withValues(alpha: 0.14)),
                      labelStyle: TextStyle(color: statusColor, fontSize: 12),
                    ),
                  ),
                  IconButton.filledTonal(
                    tooltip: '完成',
                    visualDensity: VisualDensity.compact,
                    onPressed: task.active ? onDone : null,
                    icon: const Icon(Icons.check, size: 18),
                  ),
                  const SizedBox(width: 4),
                  IconButton(
                    tooltip: '取消',
                    visualDensity: VisualDensity.compact,
                    onPressed: task.active ? onCancel : null,
                    icon: const Icon(Icons.close, size: 18),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class CreateTaskPage extends StatefulWidget {
  const CreateTaskPage({
    required this.api,
    this.initialTask,
    this.initialFocus,
    super.key,
  });

  final ApiClient api;
  final TaskItem? initialTask;
  final TaskEditFocus? initialFocus;

  @override
  State<CreateTaskPage> createState() => _CreateTaskPageState();
}

class _CreateTaskPageState extends State<CreateTaskPage> {
  final scrollController = ScrollController();
  final naturalController = TextEditingController();
  final titleController = TextEditingController();
  final contentController = TextEditingController();
  final categoryController = TextEditingController(text: '默认');
  final intervalController = TextEditingController(text: '10');
  final titleFocusNode = FocusNode();
  final contentFocusNode = FocusNode();
  final categoryFocusNode = FocusNode();
  final intervalFocusNode = FocusNode();
  final contentSectionKey = GlobalKey();
  final categorySectionKey = GlobalKey();
  final reminderSectionKey = GlobalKey();
  DateTime remindTime = DateTime.now().add(const Duration(minutes: 10));
  bool saving = false;
  bool get editing => widget.initialTask != null;

  @override
  void initState() {
    super.initState();
    final task = widget.initialTask;
    if (task != null) {
      titleController.text = task.title;
      contentController.text = task.content ?? '';
      categoryController.text = task.category;
      intervalController.text = '${task.remindIntervalMinutes}';
      remindTime = task.remindTime;
    }
    WidgetsBinding.instance.addPostFrameCallback((_) => applyInitialFocus());
  }

  @override
  void dispose() {
    scrollController.dispose();
    naturalController.dispose();
    titleController.dispose();
    contentController.dispose();
    categoryController.dispose();
    intervalController.dispose();
    titleFocusNode.dispose();
    contentFocusNode.dispose();
    categoryFocusNode.dispose();
    intervalFocusNode.dispose();
    super.dispose();
  }

  Future<void> applyInitialFocus() async {
    if (!mounted || widget.initialFocus == null) return;
    final targetKey = switch (widget.initialFocus!) {
      TaskEditFocus.title || TaskEditFocus.content => contentSectionKey,
      TaskEditFocus.category => categorySectionKey,
      TaskEditFocus.remindTime || TaskEditFocus.interval => reminderSectionKey,
    };
    final targetContext = targetKey.currentContext;
    if (targetContext != null) {
      await Scrollable.ensureVisible(
        targetContext,
        duration: const Duration(milliseconds: 260),
        curve: Curves.easeOutCubic,
      );
    }
    if (!mounted) return;
    switch (widget.initialFocus!) {
      case TaskEditFocus.title:
        titleFocusNode.requestFocus();
      case TaskEditFocus.content:
        contentFocusNode.requestFocus();
      case TaskEditFocus.category:
        categoryFocusNode.requestFocus();
      case TaskEditFocus.interval:
        intervalFocusNode.requestFocus();
      case TaskEditFocus.remindTime:
        await pickDateTime();
    }
  }

  Future<void> saveNatural() async {
    final text = naturalController.text.trim();
    if (text.isEmpty) {
      showMessage('先输入一句话任务');
      return;
    }
    await save(() => widget.api.parseCreate(text));
  }

  Future<void> saveManual() async {
    await save(
      () {
        final title = titleController.text.trim();
        if (title.isEmpty) {
          throw ApiException('请填写任务标题');
        }
        final content = contentController.text.trim().isEmpty
            ? null
            : contentController.text.trim();
        final category = categoryController.text.trim().isEmpty
            ? '默认'
            : categoryController.text.trim();
        final interval = int.tryParse(intervalController.text) ?? 10;
        final task = widget.initialTask;
        if (task == null) {
          return widget.api.createTask(
            title: title,
            content: content,
            category: category,
            remindTime: remindTime,
            intervalMinutes: interval,
          );
        }
        return widget.api.updateTask(
          id: task.id,
          title: title,
          content: content,
          category: category,
          remindTime: remindTime,
          intervalMinutes: interval,
        );
      },
    );
  }

  Future<void> save(Future<TaskItem> Function() action) async {
    setState(() => saving = true);
    try {
      await action();
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (!mounted) return;
      setState(() => saving = false);
      showMessage('$e');
    }
  }

  void showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> pickDateTime() async {
    final date = await showDatePicker(
      context: context,
      firstDate: DateTime.now().subtract(const Duration(days: 1)),
      lastDate: DateTime.now().add(const Duration(days: 365 * 3)),
      initialDate: remindTime,
    );
    if (date == null || !mounted) return;
    final time = await showTimePicker(
        context: context, initialTime: TimeOfDay.fromDateTime(remindTime));
    if (time == null) return;
    setState(() {
      remindTime =
          DateTime(date.year, date.month, date.day, time.hour, time.minute);
    });
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: Text(editing ? '编辑任务' : '新增任务')),
      body: ListView(
        controller: scrollController,
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
        children: [
          if (!editing) ...[
            FormSection(
              icon: Icons.auto_awesome,
              title: '智能创建',
              child: Column(
                children: [
                  TextField(
                    controller: naturalController,
                    minLines: 2,
                    maxLines: 4,
                    decoration: const InputDecoration(
                      labelText: '一句话创建',
                      hintText: '例如：明天下午三点提醒我联系客户',
                    ),
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: saving ? null : saveNatural,
                      icon: const Icon(Icons.auto_awesome),
                      label: const Text('解析并创建'),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
          ],
          FormSection(
            key: contentSectionKey,
            icon: Icons.edit_note_outlined,
            title: '任务内容',
            child: Column(
              children: [
                TextField(
                  controller: titleController,
                  focusNode: titleFocusNode,
                  decoration: const InputDecoration(
                    labelText: '标题',
                    prefixIcon: Icon(Icons.title),
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: contentController,
                  focusNode: contentFocusNode,
                  minLines: 3,
                  maxLines: 5,
                  decoration: const InputDecoration(
                    labelText: '内容',
                    alignLabelWithHint: true,
                    prefixIcon: Icon(Icons.notes_outlined),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          FormSection(
            key: categorySectionKey,
            icon: Icons.label_outline,
            title: '分类',
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: categoryController,
                  focusNode: categoryFocusNode,
                  decoration: const InputDecoration(
                    labelText: '标签分类',
                    hintText: '例如：工作、生活、学习、客户',
                    prefixIcon: Icon(Icons.label_outline),
                  ),
                ),
                const SizedBox(height: 10),
                QuickCategoryChips(
                  onPick: (value) =>
                      setState(() => categoryController.text = value),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          FormSection(
            key: reminderSectionKey,
            icon: Icons.notifications_active_outlined,
            title: '提醒设置',
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color:
                        colors.surfaceContainerHighest.withValues(alpha: 0.4),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: colors.outlineVariant),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.event_available_outlined,
                          color: colors.primary),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          DateFormat('yyyy-MM-dd HH:mm').format(remindTime),
                          style: Theme.of(context)
                              .textTheme
                              .titleSmall
                              ?.copyWith(fontWeight: FontWeight.w700),
                        ),
                      ),
                      OutlinedButton.icon(
                        onPressed: pickDateTime,
                        icon: const Icon(Icons.event),
                        label: const Text('选择'),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: intervalController,
                  focusNode: intervalFocusNode,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: '重复提醒间隔（分钟）',
                    prefixIcon: Icon(Icons.repeat),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          SizedBox(
            height: 48,
            child: FilledButton.icon(
              onPressed: saving ? null : saveManual,
              icon: saving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.save_outlined),
              label: Text(editing ? '保存修改' : '创建任务'),
            ),
          ),
        ],
      ),
    );
  }
}

class QuickCategoryChips extends StatelessWidget {
  const QuickCategoryChips({required this.onPick, super.key});

  final ValueChanged<String> onPick;

  @override
  Widget build(BuildContext context) {
    const categories = ['默认', '工作', '生活', '学习', '客户', '紧急'];
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final category in categories)
          ActionChip(
            avatar: const Icon(Icons.label_outline, size: 16),
            label: Text(category),
            onPressed: () => onPick(category),
          ),
      ],
    );
  }
}

class FormSection extends StatelessWidget {
  const FormSection({
    required this.icon,
    required this.title,
    required this.child,
    this.onTap,
    super.key,
  });

  final IconData icon;
  final String title;
  final Widget child;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Material(
      color: colors.surface,
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: colors.outlineVariant),
            boxShadow: [
              BoxShadow(
                color: colors.shadow.withValues(alpha: 0.03),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon, size: 20, color: colors.primary),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      title,
                      style: Theme.of(context)
                          .textTheme
                          .titleSmall
                          ?.copyWith(fontWeight: FontWeight.w800),
                    ),
                  ),
                  if (onTap != null)
                    Icon(Icons.edit_outlined, size: 18, color: colors.primary),
                ],
              ),
              const SizedBox(height: 12),
              child,
            ],
          ),
        ),
      ),
    );
  }
}

class TaskDetailPage extends StatefulWidget {
  const TaskDetailPage({required this.api, required this.taskId, super.key});

  final ApiClient api;
  final int taskId;

  @override
  State<TaskDetailPage> createState() => _TaskDetailPageState();
}

class _TaskDetailPageState extends State<TaskDetailPage> {
  TaskDetail? detail;
  String? error;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    try {
      final data = await widget.api.getTask(widget.taskId);
      setState(() {
        detail = data;
        error = null;
      });
    } catch (e) {
      setState(() => error = '$e');
    }
  }

  Future<void> openEditor(TaskDetail task, {TaskEditFocus? focus}) {
    return Navigator.of(context)
        .push(MaterialPageRoute(
            builder: (_) => CreateTaskPage(
                  api: widget.api,
                  initialTask: task,
                  initialFocus: focus,
                )))
        .then((_) => load());
  }

  @override
  Widget build(BuildContext context) {
    final task = detail;
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: const Text('任务详情'),
        actions: [
          if (task != null)
            IconButton(
              tooltip: '编辑任务',
              onPressed: () => openEditor(task),
              icon: const Icon(Icons.edit_outlined),
            ),
        ],
      ),
      body: task == null
          ? Center(child: Text(error ?? '加载中...'))
          : RefreshIndicator(
              onRefresh: load,
              child: ListView(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 28),
                children: [
                  Material(
                    color: colors.primaryContainer.withValues(alpha: 0.42),
                    borderRadius: BorderRadius.circular(8),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(8),
                      onTap: () => openEditor(task, focus: TaskEditFocus.title),
                      child: Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(
                              color: colors.primary.withValues(alpha: 0.18)),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 46,
                              height: 46,
                              decoration: BoxDecoration(
                                color: taskStatusColor(task)
                                    .withValues(alpha: 0.14),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Icon(taskStatusIcon(task),
                                  color: taskStatusColor(task)),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Expanded(
                                        child: Text(
                                          task.title,
                                          style: Theme.of(context)
                                              .textTheme
                                              .titleLarge
                                              ?.copyWith(
                                                  fontWeight: FontWeight.w800),
                                        ),
                                      ),
                                      Icon(Icons.edit_outlined,
                                          size: 18, color: colors.primary),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  Wrap(
                                    spacing: 8,
                                    runSpacing: 8,
                                    children: [
                                      DetailPill(
                                          icon: Icons.flag_outlined,
                                          label: task.statusLabel),
                                      DetailPill(
                                          icon: Icons.label_outline,
                                          label: task.category,
                                          onTap: () => openEditor(task,
                                              focus: TaskEditFocus.category)),
                                      DetailPill(
                                          icon: Icons.notifications_outlined,
                                          label: '${task.remindCount} 次提醒'),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  FormSection(
                    icon: Icons.schedule_outlined,
                    title: '提醒时间',
                    child: Column(
                      children: [
                        DetailInfoRow(
                          icon: Icons.event_available_outlined,
                          label: '原定时间',
                          value: DateFormat('yyyy-MM-dd HH:mm')
                              .format(task.remindTime),
                          onTap: () =>
                              openEditor(task, focus: TaskEditFocus.remindTime),
                        ),
                        const SizedBox(height: 10),
                        DetailInfoRow(
                          icon: Icons.notifications_active_outlined,
                          label: '下次提醒',
                          value: DateFormat('yyyy-MM-dd HH:mm')
                              .format(task.nextRemindTime),
                          onTap: () =>
                              openEditor(task, focus: TaskEditFocus.remindTime),
                        ),
                        const SizedBox(height: 10),
                        DetailInfoRow(
                          icon: Icons.repeat,
                          label: '重复间隔',
                          value: '${task.remindIntervalMinutes} 分钟',
                          onTap: () =>
                              openEditor(task, focus: TaskEditFocus.interval),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),
                  FormSection(
                    icon: Icons.notes_outlined,
                    title: '内容',
                    onTap: () => openEditor(task, focus: TaskEditFocus.content),
                    child: Text(
                      (task.content ?? '').isEmpty ? '暂无内容' : task.content!,
                      style: Theme.of(context).textTheme.bodyLarge?.copyWith(
                            color: (task.content ?? '').isEmpty
                                ? colors.onSurfaceVariant
                                : null,
                          ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  FormSection(
                    icon: Icons.history,
                    title: '提醒日志',
                    child: task.logs.isEmpty
                        ? Text(
                            '还没有发送记录',
                            style: TextStyle(color: colors.onSurfaceVariant),
                          )
                        : Column(
                            children: [
                              for (final log in task.logs) ...[
                                ReminderLogTile(log: log),
                                if (log != task.logs.last)
                                  Divider(
                                    height: 18,
                                    color: colors.outlineVariant,
                                  ),
                              ],
                            ],
                          ),
                  ),
                ],
              ),
            ),
    );
  }
}

class DetailPill extends StatelessWidget {
  const DetailPill({
    required this.icon,
    required this.label,
    this.onTap,
    super.key,
  });

  final IconData icon;
  final String label;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Material(
      color: colors.surface.withValues(alpha: 0.8),
      borderRadius: BorderRadius.circular(8),
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 6),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: colors.outlineVariant),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 15, color: colors.primary),
              const SizedBox(width: 5),
              Text(label, style: Theme.of(context).textTheme.labelMedium),
              if (onTap != null) ...[
                const SizedBox(width: 4),
                Icon(Icons.edit_outlined, size: 13, color: colors.primary),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class DetailInfoRow extends StatelessWidget {
  const DetailInfoRow({
    required this.icon,
    required this.label,
    required this.value,
    this.onTap,
    super.key,
  });

  final IconData icon;
  final String label;
  final String value;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(8),
        onTap: onTap,
        child: Padding(
          padding: onTap == null
              ? EdgeInsets.zero
              : const EdgeInsets.symmetric(vertical: 6),
          child: Row(
            children: [
              Icon(icon, size: 20, color: colors.primary),
              const SizedBox(width: 10),
              Expanded(
                child: Text(label,
                    style: TextStyle(color: colors.onSurfaceVariant)),
              ),
              const SizedBox(width: 10),
              Flexible(
                child: Text(
                  value,
                  textAlign: TextAlign.right,
                  style: Theme.of(context)
                      .textTheme
                      .bodyMedium
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
              ),
              if (onTap != null) ...[
                const SizedBox(width: 8),
                Icon(Icons.edit_outlined, size: 17, color: colors.primary),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class ReminderLogTile extends StatelessWidget {
  const ReminderLogTile({required this.log, super.key});

  final ReminderLog log;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final success = log.result == 'success';
    final color = success ? Colors.green : colors.error;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          success ? Icons.check_circle_outline : Icons.error_outline,
          color: color,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      '${log.channel} · ${success ? '成功' : '失败'}',
                      style: Theme.of(context)
                          .textTheme
                          .titleSmall
                          ?.copyWith(fontWeight: FontWeight.w700),
                    ),
                  ),
                  Text(
                    DateFormat('MM-dd HH:mm:ss').format(log.createdAt),
                    style: TextStyle(
                      color: colors.onSurfaceVariant,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                log.errorMessage ?? log.message,
                style: TextStyle(color: colors.onSurfaceVariant),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({required this.api, this.embedded = false, super.key});

  final ApiClient api;
  final bool embedded;

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final webhookController = TextEditingController();
  final secretController = TextEditingController();
  final intervalController = TextEditingController(text: '10');
  final notionTokenController = TextEditingController();
  final notionDataSourceController = TextEditingController();
  final notionTitlePropertyController = TextEditingController(text: 'Name');
  final notionTimePropertyController = TextEditingController(text: '提醒时间');
  final notionContentPropertyController = TextEditingController(text: '内容');
  final notionCategoryPropertyController = TextEditingController(text: '分类');
  final notionIntervalPropertyController = TextEditingController(text: '提醒间隔');
  final notionStatusPropertyController = TextEditingController(text: '状态');
  final notionCreatedTimePropertyController =
      TextEditingController(text: '创建时间');
  final notionSyncIntervalController = TextEditingController(text: '5');
  bool enableDingding = true;
  bool enableAppNotify = true;
  bool enableCalendar = false;
  bool enableNotionSync = false;
  bool loading = true;
  bool testingDingding = false;
  bool syncingNotion = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    webhookController.dispose();
    secretController.dispose();
    intervalController.dispose();
    notionTokenController.dispose();
    notionDataSourceController.dispose();
    notionTitlePropertyController.dispose();
    notionTimePropertyController.dispose();
    notionContentPropertyController.dispose();
    notionCategoryPropertyController.dispose();
    notionIntervalPropertyController.dispose();
    notionStatusPropertyController.dispose();
    notionCreatedTimePropertyController.dispose();
    notionSyncIntervalController.dispose();
    super.dispose();
  }

  Future<void> load() async {
    try {
      final settings = await widget.api.getSettings();
      setState(() {
        webhookController.text = settings.dingdingWebhook ?? '';
        secretController.text = settings.dingdingSecret ?? '';
        intervalController.text = '${settings.defaultRemindIntervalMinutes}';
        notionTokenController.text = settings.notionToken ?? '';
        notionDataSourceController.text = settings.notionDataSourceId ?? '';
        notionTitlePropertyController.text = settings.notionTitleProperty;
        notionTimePropertyController.text = settings.notionRemindTimeProperty;
        notionContentPropertyController.text = settings.notionContentProperty;
        notionCategoryPropertyController.text = settings.notionCategoryProperty;
        notionIntervalPropertyController.text = settings.notionIntervalProperty;
        notionStatusPropertyController.text = settings.notionStatusProperty;
        notionCreatedTimePropertyController.text =
            settings.notionCreatedTimeProperty;
        notionSyncIntervalController.text =
            '${settings.notionSyncIntervalMinutes}';
        enableNotionSync = settings.enableNotionSync;
        enableDingding = settings.enableDingding;
        enableAppNotify = settings.enableAppNotify;
        enableCalendar = settings.enableCalendar;
        loading = false;
      });
    } catch (_) {
      setState(() => loading = false);
    }
  }

  AppSettings currentSettings() {
    return AppSettings(
      dingdingWebhook: webhookController.text.trim(),
      dingdingSecret: secretController.text.trim(),
      notionToken: notionTokenController.text.trim(),
      notionDataSourceId: notionDataSourceController.text.trim(),
      notionTitleProperty: notionTitlePropertyController.text.trim().isEmpty
          ? 'Name'
          : notionTitlePropertyController.text.trim(),
      notionRemindTimeProperty: notionTimePropertyController.text.trim().isEmpty
          ? '提醒时间'
          : notionTimePropertyController.text.trim(),
      notionContentProperty: notionContentPropertyController.text.trim().isEmpty
          ? '内容'
          : notionContentPropertyController.text.trim(),
      notionCategoryProperty:
          notionCategoryPropertyController.text.trim().isEmpty
              ? '分类'
              : notionCategoryPropertyController.text.trim(),
      notionIntervalProperty:
          notionIntervalPropertyController.text.trim().isEmpty
              ? '提醒间隔'
              : notionIntervalPropertyController.text.trim(),
      notionStatusProperty: notionStatusPropertyController.text.trim().isEmpty
          ? '状态'
          : notionStatusPropertyController.text.trim(),
      notionCreatedTimeProperty:
          notionCreatedTimePropertyController.text.trim().isEmpty
              ? '创建时间'
              : notionCreatedTimePropertyController.text.trim(),
      enableNotionSync: enableNotionSync,
      notionSyncIntervalMinutes:
          int.tryParse(notionSyncIntervalController.text) ?? 5,
      defaultRemindIntervalMinutes: int.tryParse(intervalController.text) ?? 10,
      enableDingding: enableDingding,
      enableAppNotify: enableAppNotify,
      enableCalendar: enableCalendar,
    );
  }

  Future<void> save() async {
    try {
      await widget.api.saveSettings(currentSettings());
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('设置已保存')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    }
  }

  Future<void> testDingding() async {
    setState(() => testingDingding = true);
    try {
      await widget.api.testDingding(
        webhook: webhookController.text.trim(),
        secret: secretController.text.trim(),
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('钉钉测试消息已发送')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('发送失败：$e')));
    } finally {
      if (mounted) {
        setState(() => testingDingding = false);
      }
    }
  }

  Future<void> syncNotion() async {
    if (notionTokenController.text.trim().isEmpty ||
        notionDataSourceController.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('先填写 Notion Token 和数据库/数据源 ID')),
      );
      return;
    }
    setState(() => syncingNotion = true);
    try {
      await widget.api.healthCheck();
      await widget.api.saveSettings(currentSettings());
      final result = await widget.api.importNotionTasks(
        notionToken: notionTokenController.text.trim(),
        dataSourceId: notionDataSourceController.text.trim(),
        titleProperty: notionTitlePropertyController.text.trim().isEmpty
            ? 'Name'
            : notionTitlePropertyController.text.trim(),
        remindTimeProperty: notionTimePropertyController.text.trim().isEmpty
            ? '提醒时间'
            : notionTimePropertyController.text.trim(),
        contentProperty: notionContentPropertyController.text.trim(),
        categoryProperty: notionCategoryPropertyController.text.trim(),
        intervalProperty: notionIntervalPropertyController.text.trim(),
        statusProperty: notionStatusPropertyController.text.trim().isEmpty
            ? '状态'
            : notionStatusPropertyController.text.trim(),
        createdTimeProperty:
            notionCreatedTimePropertyController.text.trim().isEmpty
                ? '创建时间'
                : notionCreatedTimePropertyController.text.trim(),
        defaultIntervalMinutes: int.tryParse(intervalController.text) ?? 10,
      );
      if (!mounted) return;
      final extra = result.errors.isEmpty ? '' : '，${result.errors.first}';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
              'Notion 同步完成：新增 ${result.created}，更新 ${result.updated}，跳过 ${result.skipped}，失败 ${result.failed}$extra'),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('同步失败：${friendlySyncError(e)}')),
      );
    } finally {
      if (mounted) {
        setState(() => syncingNotion = false);
      }
    }
  }

  String friendlySyncError(Object error) {
    final message = '$error';
    if (message.contains('Failed to fetch') ||
        message.contains('XMLHttpRequest') ||
        message.contains('SocketException')) {
      return '连接不到后端 ${widget.api.baseUrl}。请确认后端窗口还在运行，或重启“一键启动后端.command”后再同步。';
    }
    return message;
  }

  @override
  Widget build(BuildContext context) {
    final body = loading
        ? const Center(child: CircularProgressIndicator())
        : _buildSettingsBody(context);
    if (widget.embedded) {
      return body;
    }
    return Scaffold(appBar: AppBar(title: const Text('设置')), body: body);
  }

  Widget _buildSettingsBody(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 96),
      children: [
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: colors.primaryContainer.withValues(alpha: 0.45),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: colors.outlineVariant),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.info_outline, color: colors.primary),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  '如果机器人只开了关键字安全设置，填 Webhook 一个信息就够；如果开了加签，还要填 Secret。后端到提醒时间后会发送到钉钉，任务完成或取消后不会继续提醒。',
                  style: TextStyle(color: colors.onSurface),
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Text('钉钉提醒',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        TextField(
          controller: webhookController,
          minLines: 2,
          maxLines: 4,
          decoration: const InputDecoration(
            labelText: '钉钉机器人 Webhook',
            hintText: 'https://oapi.dingtalk.com/robot/send?access_token=...',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: secretController,
          decoration: const InputDecoration(
            labelText: '加签 Secret（可选）',
            hintText: 'SEC...',
            prefixIcon: Icon(Icons.key_outlined),
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: enableDingding,
          onChanged: (value) => setState(() => enableDingding = value),
          title: const Text('启用钉钉提醒'),
          subtitle: const Text('关闭后仍会记录 App 内提醒日志，但不会发到钉钉群。'),
        ),
        OutlinedButton.icon(
          onPressed: testingDingding ? null : testDingding,
          icon: testingDingding
              ? const SizedBox(
                  width: 18,
                  height: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                )
              : const Icon(Icons.send_outlined),
          label: Text(testingDingding ? '发送中...' : '发送测试消息'),
        ),
        const Divider(height: 28),
        Text('Notion 同步',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: colors.surface,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: colors.outlineVariant),
          ),
          child: Column(
            children: [
              TextField(
                controller: notionTokenController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Notion Internal Integration Token',
                  hintText: 'secret_...',
                  prefixIcon: Icon(Icons.key_outlined),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: notionDataSourceController,
                decoration: const InputDecoration(
                  labelText: '数据库 / 数据源 ID 或链接',
                  hintText: '粘贴 Notion 数据库链接也可以',
                  prefixIcon: Icon(Icons.dataset_linked_outlined),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: notionTitlePropertyController,
                decoration: const InputDecoration(
                  labelText: '标题属性',
                  prefixIcon: Icon(Icons.title),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: notionTimePropertyController,
                decoration: const InputDecoration(
                  labelText: '提醒时间属性',
                  prefixIcon: Icon(Icons.event_outlined),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: notionContentPropertyController,
                decoration: const InputDecoration(
                  labelText: '内容属性',
                  prefixIcon: Icon(Icons.notes_outlined),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: notionCategoryPropertyController,
                decoration: const InputDecoration(
                  labelText: '分类属性',
                  prefixIcon: Icon(Icons.label_outline),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: notionIntervalPropertyController,
                keyboardType: TextInputType.text,
                decoration: const InputDecoration(
                  labelText: '重复间隔属性',
                  hintText: '数字属性，单位分钟；没有则用默认间隔',
                  prefixIcon: Icon(Icons.repeat),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: notionStatusPropertyController,
                decoration: const InputDecoration(
                  labelText: '状态属性',
                  hintText: '未开始 / 进行中 / 完成',
                  prefixIcon: Icon(Icons.fact_check_outlined),
                ),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: notionCreatedTimePropertyController,
                decoration: const InputDecoration(
                  labelText: '创建时间属性',
                  hintText: '用于和任务名称组成唯一键',
                  prefixIcon: Icon(Icons.access_time),
                ),
              ),
              const SizedBox(height: 10),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                value: enableNotionSync,
                onChanged: (value) => setState(() => enableNotionSync = value),
                title: const Text('启用 Notion 自动同步'),
                subtitle: const Text('后端会按间隔自动拉取 Notion 并更新任务。'),
              ),
              TextField(
                controller: notionSyncIntervalController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  labelText: '自动同步间隔（分钟）',
                  prefixIcon: Icon(Icons.update),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: syncingNotion ? null : syncNotion,
                  icon: syncingNotion
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.sync),
                  label: Text(syncingNotion ? '同步中...' : '从 Notion 同步任务'),
                ),
              ),
            ],
          ),
        ),
        const Divider(height: 28),
        Text('提醒规则',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w700)),
        const SizedBox(height: 8),
        TextField(
          controller: intervalController,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(
            labelText: '默认重复提醒间隔（分钟）',
            border: OutlineInputBorder(),
            prefixIcon: Icon(Icons.timer_outlined),
          ),
        ),
        const SizedBox(height: 8),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: enableAppNotify,
          onChanged: (value) => setState(() => enableAppNotify = value),
          title: const Text('记录 App 内提醒'),
          subtitle: const Text('保留提醒日志，方便在任务详情里追踪发送结果。'),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: enableCalendar,
          onChanged: (value) => setState(() => enableCalendar = value),
          title: const Text('启用日历写入'),
          subtitle: const Text('当前版本会记录日历通道日志；真正写入系统日历可后续接入。'),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(
          onPressed: save,
          icon: const Icon(Icons.save_outlined),
          label: const Text('保存设置'),
        ),
      ],
    );
  }
}
