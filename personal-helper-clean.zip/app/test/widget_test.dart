import 'package:flutter_test/flutter_test.dart';
import 'package:task_reminder_app/main.dart';

void main() {
  testWidgets('renders task reminder app', (tester) async {
    await tester.pumpWidget(const TaskReminderApp());
    expect(find.text('Personal Helper'), findsOneWidget);
  });
}
