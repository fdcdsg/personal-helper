# TaskReminder Flutter 客户端

这是任务提醒系统的跨端客户端代码，使用同一套 Flutter UI 连接 FastAPI 后端。

## 已实现

- 任务列表自动刷新
- 一句话创建任务
- 手动创建任务
- 完成、取消、延后 10 分钟、延后 30 分钟、延后 1 小时
- 任务详情和提醒日志
- 钉钉 Webhook、默认提醒间隔、提醒开关设置
- 支持自定义后端地址，用于本机、局域网或云服务器

## 首次生成平台目录

当前目录包含核心 Flutter 代码。本机安装 Flutter SDK 后，在 `app` 目录执行：

```bash
flutter create --platforms=android,ios,windows,macos,linux,web .
flutter pub get
flutter analyze
```

## 运行

先启动后端：

```bash
cd ../backend
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

再启动客户端：

```bash
cd ../app
flutter run
```

电脑本机默认后端地址为：

```text
http://127.0.0.1:8000
```

手机真机调试时，手机和电脑需要在同一 Wi-Fi，客户端里把后端地址改成电脑局域网 IP，例如：

```text
http://192.168.1.8:8000
```

后续部署云服务器后，只需要把客户端里的后端地址改成公网 API 地址。
